import { d as e, e as a, u as o, w as n, o as r } from "./index-BMNNx3yZ.js";
/* empty css               */
const i = /* @__PURE__ */ e({
  __name: "pinia",
  setup(t) {
    return (s, p) => (r(), a(o(n)));
  }
});
export {
  i as default
};
