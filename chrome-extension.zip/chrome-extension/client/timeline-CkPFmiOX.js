import { d as M, ag as V, i as f, Y as I, ah as D, ai as U, aj as j, c as n, o as l, b as d, a as N, u as e, T as L, ak as R, s as r, al as $, F, v as P, h as E, n as W, H as q, t as z, E as H, W as K, q as h, am as Y, a7 as G, x as k, ae as J, e as O, an as Q, A, af as C, ao as X } from "./index-BMNNx3yZ.js";
const Z = {
  "h-full": "",
  flex: "",
  "flex-col": "",
  p2: ""
}, ee = {
  class: "relative mb-1 w-full flex items-center justify-end pb-1",
  border: "b dashed base"
}, te = {
  key: 0,
  class: "absolute left-0 text-xs text-gray-300 dark:text-gray-500"
}, ae = { class: "flex items-center gap-2 px-1" }, le = {
  key: 0,
  class: "recording recording-btn bg-[#ef4444]"
}, oe = {
  key: 1,
  class: "recording-btn bg-black op70 dark:bg-white hover:op100"
}, ne = { class: "flex items-center gap1" }, se = { class: "p2" }, ie = ["onClick"], re = ["onClick"], de = /* @__PURE__ */ M({
  __name: "TimelineLayers",
  props: /* @__PURE__ */ V({
    data: {}
  }, {
    modelValue: {},
    modelModifiers: {}
  }),
  emits: /* @__PURE__ */ V(["select", "clear"], ["update:modelValue"]),
  setup(w, { emit: y }) {
    const b = y, _ = I(), u = f(() => _.timelineLayersState.value.recordingState), c = f(() => _.timelineLayersState.value), g = f(() => u.value ? "Stop recording" : "Start recording");
    D();
    const p = U(w, "modelValue");
    function S(t) {
      p.value = t, b("select", t), E.value.updateTimelineLayersState({
        selected: t
      });
    }
    j(() => c.value.selected, (t) => {
      p.value = t;
    }, {
      immediate: !0
    });
    function s(t) {
      return {
        mouse: c.value.mouseEventEnabled,
        keyboard: c.value.keyboardEventEnabled,
        "component-event": c.value.componentEventEnabled,
        performance: c.value.performanceEventEnabled
      }[t];
    }
    function T() {
      E.value.updateTimelineLayersState({
        recordingState: !u.value
      });
    }
    function v(t) {
      const i = {
        mouse: "mouseEventEnabled",
        keyboard: "keyboardEventEnabled",
        "component-event": "componentEventEnabled",
        performance: "performanceEventEnabled"
      }[t];
      E.value.updateTimelineLayersState({
        [i]: !s(t)
      });
    }
    return (t, i) => (l(), n("div", Z, [
      d("div", ee, [
        e(u) ? N("", !0) : (l(), n("span", te, "Not recording")),
        d("div", ae, [
          L((l(), n("div", {
            class: "flex items-center gap1",
            onClick: T
          }, [
            e(u) ? (l(), n("span", le)) : (l(), n("span", oe))
          ])), [
            [
              e(R),
              { content: e(g) },
              void 0,
              { "bottom-end": !0 }
            ]
          ]),
          L((l(), n("div", {
            class: "flex items-center gap1",
            onClick: i[0] || (i[0] = (o) => b("clear"))
          }, [
            r(e($), {
              name: "baseline-delete",
              "cursor-pointer": "",
              "text-xl": "",
              op70: "",
              "hover:op100": ""
            })
          ])), [
            [
              e(R),
              { content: "Clear all timelines" },
              void 0,
              { "bottom-end": !0 }
            ]
          ]),
          L((l(), n("div", ne, [
            r(e($), {
              name: "baseline-tips-and-updates",
              "cursor-pointer": "",
              "text-xl": "",
              op70: "",
              "hover:op100": ""
            })
          ])), [
            [
              e(R),
              { content: "<p style='width: 285px'>Timeline events can cause significant performance overhead in large applications, so we recommend enabling it only when needed and on-demand. </p>", html: !0 },
              void 0,
              { "bottom-end": !0 }
            ]
          ])
        ])
      ]),
      d("ul", se, [
        (l(!0), n(F, null, P(w.data, (o) => (l(), n("li", {
          key: o.id,
          class: W(["group relative selectable-item", { active: o.id === p.value, op60: !s(o.id) }]),
          onClick: (a) => S(o.id)
        }, [
          q(z(o.label) + " ", 1),
          d("span", {
            class: "absolute right-2 rounded-1 bg-primary-500 px1 text-3 text-white op0 [.active_&]:bg-primary-400 [.active_&]:dark:bg-gray-600 group-hover:op80 hover:op100!",
            onClick: H((a) => v(o.id), ["stop"])
          }, z(s(o.id) ? "Disable" : "Enable"), 9, re)
        ], 10, ie))), 128))
      ])
    ]));
  }
}), ce = /* @__PURE__ */ K(de, [["__scopeId", "data-v-95cda1e2"]]), ue = { class: "h-full w-full" }, pe = { class: "no-scrollbar h-full flex select-none gap-2 overflow-scroll" }, ve = { class: "h-full flex flex-col" }, me = { class: "no-scrollbar h-full flex select-none gap-2 overflow-scroll" }, fe = { class: "h-full flex flex-col p2" }, _e = /* @__PURE__ */ M({
  __name: "timeline",
  setup(w) {
    const y = h(), b = h(), _ = h(!1), { width: u } = Y(b), c = f(() => _.value ? u.value < 700 : !1), g = I(), p = f(() => g.appRecords.value.map((a) => ({
      label: a.name + (a.version ? ` (${a.version})` : ""),
      value: a.id
    }))), S = f(() => p.value.map((a) => ({
      label: a.label,
      id: a.value
    }))), s = h(g.activeAppRecordId.value);
    G(() => {
      s.value = g.activeAppRecordId.value;
    });
    function T(a) {
      E.value.toggleApp(a).then(() => {
        i();
      });
    }
    const v = h(""), t = [
      {
        label: "Mouse",
        id: "mouse"
      },
      {
        label: "Keyboard",
        id: "keyboard"
      },
      {
        label: "Component events",
        id: "component-event"
      },
      {
        label: "Performance",
        id: "performance"
      }
    ];
    function i() {
      y.value?.clear();
    }
    function o() {
      i();
    }
    return (a, m) => {
      const B = ce;
      return l(), n("div", ue, [
        r(e(J), {
          ref_key: "splitpanesRef",
          ref: b,
          class: "flex-1 overflow-auto",
          horizontal: e(c),
          onReady: m[2] || (m[2] = (x) => _.value = !0)
        }, {
          default: k(() => [
            e(p).length > 1 ? (l(), O(e(C), {
              key: 0,
              border: "base h-full",
              size: "20"
            }, {
              default: k(() => [
                d("div", pe, [
                  r(e(Q), {
                    modelValue: e(s),
                    "onUpdate:modelValue": m[0] || (m[0] = (x) => A(s) ? s.value = x : null),
                    data: e(S),
                    class: "w-full",
                    onSelect: T
                  }, null, 8, ["modelValue", "data"])
                ])
              ]),
              _: 1
            })) : N("", !0),
            r(e(C), {
              border: "base",
              "h-full": ""
            }, {
              default: k(() => [
                d("div", ve, [
                  d("div", me, [
                    r(B, {
                      modelValue: e(v),
                      "onUpdate:modelValue": m[1] || (m[1] = (x) => A(v) ? v.value = x : null),
                      data: t,
                      class: "w-full",
                      onSelect: o,
                      onClear: i
                    }, null, 8, ["modelValue"])
                  ])
                ])
              ]),
              _: 1
            }),
            r(e(C), {
              relative: "",
              "h-full": "",
              size: "65"
            }, {
              default: k(() => [
                d("div", fe, [
                  r(e(X), {
                    ref_key: "timelineRef",
                    ref: y,
                    "layer-ids": [e(v)],
                    "header-visible": !1,
                    "doc-link": "",
                    "plugin-id": "",
                    "switcher-visible": !1
                  }, null, 8, ["layer-ids"])
                ])
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["horizontal"])
      ]);
    };
  }
});
export {
  _e as default
};
