import { d as T, aq as lt, ay as Z, i as w, a7 as at, c as h, a as P, o as u, b as l, F as z, v as F, n as M, u as n, t as _, s as A, a6 as rt, e as S, x as C, H, r as L, M as Q, T as E, ak as X, az as ut, av as nt, Y as ct, aA as Y, aa as dt, q as D, S as st, f as tt, U as q, a5 as ot, aB as pt, ax as K, A as G, aj as et, a8 as ht, aC as ft, aD as mt, aw as vt, a0 as yt, at as gt, I as xt, J as bt, V as wt } from "./index-BMNNx3yZ.js";
import { _ as $t } from "./SectionBlock-CT_8cHh8.js";
import { _ as _t } from "./IconTitle.vue_vue_type_script_setup_true_lang-BCP3S8LV.js";
const kt = {
  key: 0,
  relative: "",
  "code-block": ""
}, Bt = {
  flex: "~ wrap",
  "w-full": ""
}, At = ["onClick"], Ct = {
  flex: "~ gap-2",
  px3: "",
  pb3: ""
}, Pt = /* @__PURE__ */ T({
  __name: "CodeSnippets",
  props: {
    codeSnippets: {},
    eventType: {}
  },
  setup(a) {
    const i = a, t = lt(i.codeSnippets[0]), { copy: e } = Z(), o = w(() => t.value?.lang || "text");
    return at(() => {
      i.codeSnippets.includes(t.value) || (t.value = i.codeSnippets[0]);
    }), (s, r) => a.codeSnippets.length ? (u(), h("div", kt, [
      l("div", Bt, [
        (u(!0), h(z, null, F(a.codeSnippets, (d, y) => (u(), h("button", {
          key: y,
          px4: "",
          py2: "",
          border: "r base",
          hover: "bg-active",
          class: M(d === n(t) ? "" : "border-b"),
          onClick: (m) => t.value = d
        }, [
          l("div", {
            class: M(d === n(t) ? "" : "op30"),
            "font-mono": ""
          }, _(d.name), 3)
        ], 10, At))), 128)),
        r[1] || (r[1] = l("div", {
          border: "b base",
          "flex-auto": ""
        }, null, -1))
      ]),
      n(t) ? (u(), h(z, { key: 0 }, [
        A(n(rt), {
          code: n(t).code,
          lang: n(o),
          lines: !1,
          "w-full": "",
          "of-auto": "",
          p3: ""
        }, null, 8, ["code", "lang"]),
        l("div", Ct, [
          A(n(Q), {
            onClick: r[0] || (r[0] = (d) => n(e)(n(t).code, { silent: !1, type: a.eventType || `code-snippet-${n(t).name}` }))
          }, {
            icon: C(() => [
              L(s.$slots, "i-carbon-copy")
            ]),
            default: C(() => [
              r[2] || (r[2] = H(" Copy ", -1))
            ]),
            _: 3
          }),
          n(t)?.docs ? (u(), S(n(Q), {
            key: 0,
            to: n(t).docs,
            target: "_blank"
          }, {
            icon: C(() => [
              L(s.$slots, "i-carbon-catalog")
            ]),
            default: C(() => [
              r[3] || (r[3] = H(" Docs ", -1))
            ]),
            _: 3
          }, 8, ["to"])) : P("", !0)
        ])
      ], 64)) : P("", !0)
    ])) : P("", !0);
  }
}), St = ["title"], zt = /* @__PURE__ */ T({
  __name: "FilepathItem",
  props: {
    filepath: {},
    lineBreak: { type: Boolean },
    subpath: { type: Boolean }
  },
  setup(a) {
    const i = a, t = w(
      () => ({ path: i.filepath })
    ), { copy: e } = Z();
    return (o, s) => E((u(), h("button", {
      "font-mono": "",
      "hover:underline": "",
      class: M(a.lineBreak ? "" : "ws-nowrap of-hidden truncate"),
      title: a.filepath,
      onClick: s[0] || (s[0] = (r) => n(e)(a.filepath))
    }, [
      H(_(n(t).path), 1)
    ], 10, St)), [
      [n(X), "Copy file path"]
    ]);
  }
});
function jt(a) {
  return typeof a == "string" ? `'${a}'` : new Vt().serialize(a);
}
const Vt = /* @__PURE__ */ (function() {
  class a {
    #t = /* @__PURE__ */ new Map();
    compare(t, e) {
      const o = typeof t, s = typeof e;
      return o === "string" && s === "string" ? t.localeCompare(e) : o === "number" && s === "number" ? t - e : String.prototype.localeCompare.call(this.serialize(t, !0), this.serialize(e, !0));
    }
    serialize(t, e) {
      if (t === null) return "null";
      switch (typeof t) {
        case "string":
          return e ? t : `'${t}'`;
        case "bigint":
          return `${t}n`;
        case "object":
          return this.$object(t);
        case "function":
          return this.$function(t);
      }
      return String(t);
    }
    serializeObject(t) {
      const e = Object.prototype.toString.call(t);
      if (e !== "[object Object]") return this.serializeBuiltInType(e.length < 10 ? `unknown:${e}` : e.slice(8, -1), t);
      const o = t.constructor, s = o === Object || o === void 0 ? "" : o.name;
      if (s !== "" && globalThis[s] === o) return this.serializeBuiltInType(s, t);
      if (typeof t.toJSON == "function") {
        const r = t.toJSON();
        return s + (r !== null && typeof r == "object" ? this.$object(r) : `(${this.serialize(r)})`);
      }
      return this.serializeObjectEntries(s, Object.entries(t));
    }
    serializeBuiltInType(t, e) {
      const o = this["$" + t];
      if (o) return o.call(this, e);
      if (typeof e?.entries == "function") return this.serializeObjectEntries(t, e.entries());
      throw new Error(`Cannot serialize ${t}`);
    }
    serializeObjectEntries(t, e) {
      const o = Array.from(e).sort((r, d) => this.compare(r[0], d[0]));
      let s = `${t}{`;
      for (let r = 0; r < o.length; r++) {
        const [d, y] = o[r];
        s += `${this.serialize(d, !0)}:${this.serialize(y)}`, r < o.length - 1 && (s += ",");
      }
      return s + "}";
    }
    $object(t) {
      let e = this.#t.get(t);
      return e === void 0 && (this.#t.set(t, `#${this.#t.size}`), e = this.serializeObject(t), this.#t.set(t, e)), e;
    }
    $function(t) {
      const e = Function.prototype.toString.call(t);
      return e.slice(-15) === "[native code] }" ? `${t.name || ""}()[native]` : `${t.name}(${t.length})${e.replace(/\s*\n\s*/g, "")}`;
    }
    $Array(t) {
      let e = "[";
      for (let o = 0; o < t.length; o++) e += this.serialize(t[o]), o < t.length - 1 && (e += ",");
      return e + "]";
    }
    $Date(t) {
      try {
        return `Date(${t.toISOString()})`;
      } catch {
        return "Date(null)";
      }
    }
    $ArrayBuffer(t) {
      return `ArrayBuffer[${new Uint8Array(t).join(",")}]`;
    }
    $Set(t) {
      return `Set${this.$Array(Array.from(t).sort((e, o) => this.compare(e, o)))}`;
    }
    $Map(t) {
      return this.serializeObjectEntries("Map", t.entries());
    }
  }
  for (const i of ["Error", "RegExp", "URL"]) a.prototype["$" + i] = function(t) {
    return `${i}(${t})`;
  };
  for (const i of ["Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Uint16Array", "Int32Array", "Uint32Array", "Float32Array", "Float64Array"]) a.prototype["$" + i] = function(t) {
    return `${i}[${t.join(",")}]`;
  };
  for (const i of ["BigInt64Array", "BigUint64Array"]) a.prototype["$" + i] = function(t) {
    return `${i}[${t.join("n,")}${t.length > 0 ? "n" : ""}]`;
  };
  return a;
})(), It = [1779033703, -1150833019, 1013904242, -1521486534, 1359893119, -1694144372, 528734635, 1541459225], Dt = [1116352408, 1899447441, -1245643825, -373957723, 961987163, 1508970993, -1841331548, -1424204075, -670586216, 310598401, 607225278, 1426881987, 1925078388, -2132889090, -1680079193, -1046744716, -459576895, -272742522, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, -1740746414, -1473132947, -1341970488, -1084653625, -958395405, -710438585, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, -2117940946, -1838011259, -1564481375, -1474664885, -1035236496, -949202525, -778901479, -694614492, -200395387, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, -2067236844, -1933114872, -1866530822, -1538233109, -1090935817, -965641998], Tt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", O = [];
class Ut {
  _data = new J();
  _hash = new J([...It]);
  _nDataBytes = 0;
  _minBufferSize = 0;
  finalize(i) {
    i && this._append(i);
    const t = this._nDataBytes * 8, e = this._data.sigBytes * 8;
    return this._data.words[e >>> 5] |= 128 << 24 - e % 32, this._data.words[(e + 64 >>> 9 << 4) + 14] = Math.floor(t / 4294967296), this._data.words[(e + 64 >>> 9 << 4) + 15] = t, this._data.sigBytes = this._data.words.length * 4, this._process(), this._hash;
  }
  _doProcessBlock(i, t) {
    const e = this._hash.words;
    let o = e[0], s = e[1], r = e[2], d = e[3], y = e[4], m = e[5], j = e[6], V = e[7];
    for (let b = 0; b < 64; b++) {
      if (b < 16) O[b] = i[t + b] | 0;
      else {
        const p = O[b - 15], c = (p << 25 | p >>> 7) ^ (p << 14 | p >>> 18) ^ p >>> 3, $ = O[b - 2], k = ($ << 15 | $ >>> 17) ^ ($ << 13 | $ >>> 19) ^ $ >>> 10;
        O[b] = c + O[b - 7] + k + O[b - 16];
      }
      const U = y & m ^ ~y & j, W = o & s ^ o & r ^ s & r, g = (o << 30 | o >>> 2) ^ (o << 19 | o >>> 13) ^ (o << 10 | o >>> 22), f = (y << 26 | y >>> 6) ^ (y << 21 | y >>> 11) ^ (y << 7 | y >>> 25), v = V + f + U + Dt[b] + O[b], I = g + W;
      V = j, j = m, m = y, y = d + v | 0, d = r, r = s, s = o, o = v + I | 0;
    }
    e[0] = e[0] + o | 0, e[1] = e[1] + s | 0, e[2] = e[2] + r | 0, e[3] = e[3] + d | 0, e[4] = e[4] + y | 0, e[5] = e[5] + m | 0, e[6] = e[6] + j | 0, e[7] = e[7] + V | 0;
  }
  _append(i) {
    typeof i == "string" && (i = J.fromUtf8(i)), this._data.concat(i), this._nDataBytes += i.sigBytes;
  }
  _process(i) {
    let t, e = this._data.sigBytes / 64;
    i ? e = Math.ceil(e) : e = Math.max((e | 0) - this._minBufferSize, 0);
    const o = e * 16, s = Math.min(o * 4, this._data.sigBytes);
    if (o) {
      for (let r = 0; r < o; r += 16) this._doProcessBlock(this._data.words, r);
      t = this._data.words.splice(0, o), this._data.sigBytes -= s;
    }
    return new J(t, s);
  }
}
class J {
  words;
  sigBytes;
  constructor(i, t) {
    i = this.words = i || [], this.sigBytes = t === void 0 ? i.length * 4 : t;
  }
  static fromUtf8(i) {
    const t = unescape(encodeURIComponent(i)), e = t.length, o = [];
    for (let s = 0; s < e; s++) o[s >>> 2] |= (t.charCodeAt(s) & 255) << 24 - s % 4 * 8;
    return new J(o, e);
  }
  toBase64() {
    const i = [];
    for (let t = 0; t < this.sigBytes; t += 3) {
      const e = this.words[t >>> 2] >>> 24 - t % 4 * 8 & 255, o = this.words[t + 1 >>> 2] >>> 24 - (t + 1) % 4 * 8 & 255, s = this.words[t + 2 >>> 2] >>> 24 - (t + 2) % 4 * 8 & 255, r = e << 16 | o << 8 | s;
      for (let d = 0; d < 4 && t * 8 + d * 6 < this.sigBytes * 8; d++) i.push(Tt.charAt(r >>> 6 * (3 - d) & 63));
    }
    return i.join("");
  }
  concat(i) {
    if (this.words[this.sigBytes >>> 2] &= 4294967295 << 32 - this.sigBytes % 4 * 8, this.words.length = Math.ceil(this.sigBytes / 4), this.sigBytes % 4) for (let t = 0; t < i.sigBytes; t++) {
      const e = i.words[t >>> 2] >>> 24 - t % 4 * 8 & 255;
      this.words[this.sigBytes + t >>> 2] |= e << 24 - (this.sigBytes + t) % 4 * 8;
    }
    else for (let t = 0; t < i.sigBytes; t += 4) this.words[this.sigBytes + t >>> 2] = i.words[t >>> 2];
    this.sigBytes += i.sigBytes;
  }
}
function Ot(a) {
  return new Ut().finalize(a).toBase64();
}
function Ft(a) {
  return Ot(jt(a));
}
const Et = /* @__PURE__ */ T({
  __name: "AssetFontPreview",
  props: {
    asset: {}
  },
  setup(a) {
    const i = a, t = w(() => `devtools-assets-${Ft(i.asset)}`);
    return ut(w(() => `
  @font-face {
    font-family: '${t.value}';
    src: url('${i.asset.publicPath}');
  }
`)), (e, o) => (u(), h("div", {
      "of-hidden": "",
      style: nt({ fontFamily: `'${n(t)}'` })
    }, " Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz ", 4));
  }
}), Mt = {
  flex: "",
  "items-center": "",
  "justify-center": "",
  "of-hidden": "",
  "bg-active": "",
  "object-cover": "",
  p1: ""
}, Lt = ["src"], Rt = {
  key: 2,
  "i-carbon-document": "",
  "text-3xl": "",
  op20: ""
}, Nt = {
  key: 3,
  "w-full": "",
  "self-start": "",
  p4: ""
}, qt = ["textContent"], Gt = { key: 4 }, Jt = ["src", "autoplay", "controls"], Ht = { key: 5 }, Kt = {
  key: 0,
  "i-carbon-volume-up": "",
  "text-3xl": "",
  op20: ""
}, Wt = ["src"], Xt = {
  key: 6,
  "i-vscode-icons-file-type-wasm": "",
  "text-3xl": ""
}, Yt = {
  key: 7,
  "i-carbon-help": "",
  "text-3xl": "",
  op20: ""
}, it = /* @__PURE__ */ T({
  __name: "AssetPreview",
  props: {
    asset: {},
    textContent: {},
    detail: { type: Boolean }
  },
  setup(a) {
    return (i, t) => {
      const e = Et;
      return u(), h("div", Mt, [
        a.asset.type === "image" ? (u(), h("img", {
          key: 0,
          src: a.asset.publicPath
        }, null, 8, Lt)) : a.asset.type === "font" ? (u(), S(e, {
          key: a.asset.publicPath,
          asset: a.asset,
          "self-stretch": "",
          p2: "",
          "text-2xl": ""
        }, null, 8, ["asset"])) : a.asset.type === "text" && !a.textContent ? (u(), h("div", Rt)) : a.asset.type === "text" && a.textContent ? (u(), h("div", Nt, [
          l("pre", {
            "max-h-10rem": "",
            "of-hidden": "",
            "text-xs": "",
            "font-mono": "",
            textContent: _(a.textContent)
          }, null, 8, qt)
        ])) : a.asset.type === "video" ? (u(), h("div", Gt, [
          l("video", {
            src: a.asset.publicPath,
            autoplay: a.detail,
            controls: a.detail
          }, null, 8, Jt)
        ])) : a.asset.type === "audio" ? (u(), h("div", Ht, [
          a.detail ? (u(), h("audio", {
            key: 1,
            src: a.asset.publicPath,
            controls: ""
          }, null, 8, Wt)) : (u(), h("div", Kt))
        ])) : a.asset.type === "wasm" ? (u(), h("div", Xt)) : (u(), h("div", Yt))
      ]);
    };
  }
}), Qt = {
  flex: "~ col gap-4",
  "min-h-full": "",
  "w-full": "",
  "of-hidden": "",
  p4: ""
}, Zt = {
  flex: "~",
  "items-center": "",
  "justify-center": ""
}, te = {
  "max-w-full": "",
  "w-full": "",
  "table-fixed": ""
}, ee = {
  flex: "~ gap-1",
  "w-full": "",
  "items-center": ""
}, ne = {
  flex: "~ gap-1",
  "w-full": "",
  "items-center": "",
  "of-hidden": ""
}, se = {
  "flex-auto": "",
  "of-hidden": "",
  truncate: "",
  "ws-pre": "",
  "font-mono": ""
}, oe = { capitalize: "" }, ie = { key: 0 }, le = { op70: "" }, ae = { flex: "~ gap2 wrap" }, re = /* @__PURE__ */ T({
  __name: "AssetDetails",
  props: {
    modelValue: {}
  },
  setup(a, { emit: i }) {
    const t = a, e = i, o = ct(), s = st(t, "modelValue", e, { passive: !0 }), r = w(() => o.vitePluginDetected.value), d = Y(() => K.value.getAssetImporters(s.value.publicPath).then((p) => p), []), y = w(() => dt.value), m = Y(() => {
      if (s.value.type === "image")
        return K.value.getImageMeta(s.value.filePath).then((p) => p);
    }), j = D(), V = D(0), b = Y(async () => {
      if (s.value.type !== "text")
        return;
      V.value;
      const p = await K.value.getTextAssetContent(s.value.filePath).then((c) => c);
      return j.value = p, p;
    }), U = w(() => {
      const p = [];
      if (s.value.type === "image") {
        const c = m.value?.width ? `
  width="${m.value.width}"
  height="${m.value.height}" ` : " ";
        return p.push(
          { lang: "vue-html", code: `<img${c}
  src="${s.value.publicPath}"
/>`, name: "Plain Image" }
        ), p;
      }
      return p.push({
        lang: "html",
        code: `<a download href="${s.value.publicPath}">
  Download ${s.value.path.split("/").slice(-1)[0]}
</a>`,
        name: "Download link"
      }), p;
    }), { copy: W } = Z(), g = pt(() => s.value.mtime), f = w(() => {
      const p = s.value.size;
      return p < 1024 ? `${p} B` : p < 1024 * 1024 ? `${(p / 1024).toFixed(2)} KB` : `${(p / 1024 / 1024).toFixed(2)} MB`;
    }), v = w(() => {
      if (!m.value?.width || !m.value?.height)
        return "";
      const p = ($, k) => k ? p(k, $ % k) : $, c = p(m.value.width, m.value.height);
      return c > 3 ? `${m.value.width / c}:${m.value.height / c}` : "";
    }), I = w(() => [
      "image",
      "text",
      "video",
      "audio",
      "font"
    ].includes(s.value.type));
    return (p, c) => {
      const $ = it, k = zt, R = ot("RouterLink"), x = Pt;
      return u(), h("div", Qt, [
        n(I) ? (u(), h(z, { key: 0 }, [
          c[2] || (c[2] = l("div", {
            flex: "~ gap2",
            "mb--2": "",
            "items-center": "",
            op50: ""
          }, [
            l("div", { "x-divider": "" }),
            l("div", { "flex-none": "" }, " Preview "),
            l("div", { "x-divider": "" })
          ], -1)),
          l("div", Zt, [
            A($, {
              detail: "",
              "max-h-80": "",
              "min-h-20": "",
              "min-w-20": "",
              "w-auto": "",
              rounded: "",
              border: "~ base",
              asset: n(s),
              "text-content": n(b)
            }, null, 8, ["asset", "text-content"])
          ])
        ], 64)) : P("", !0),
        c[12] || (c[12] = l("div", {
          flex: "~ gap2",
          "mb--2": "",
          "items-center": "",
          op50: ""
        }, [
          l("div", { "x-divider": "" }),
          l("div", { "flex-none": "" }, " Details "),
          l("div", { "x-divider": "" })
        ], -1)),
        l("table", te, [
          l("tbody", null, [
            l("tr", null, [
              c[3] || (c[3] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                op50: ""
              }, " Filepath ", -1)),
              l("td", null, [
                l("div", ee, [
                  A(k, {
                    filepath: n(s).filePath,
                    "text-left": ""
                  }, null, 8, ["filepath"]),
                  n(r) && n(y) ? E((u(), S(n(q), {
                    key: 0,
                    title: "Open in Editor",
                    icon: "i-carbon-launch",
                    action: "",
                    "flex-none": "",
                    border: !1,
                    onClick: c[0] || (c[0] = (B) => n(tt)(n(s).filePath))
                  }, null, 512)), [
                    [n(X), "Open in Editor"]
                  ]) : P("", !0)
                ])
              ])
            ]),
            l("tr", null, [
              c[4] || (c[4] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                op50: ""
              }, " Public Path ", -1)),
              l("td", null, [
                l("div", ne, [
                  l("div", se, _(n(s).publicPath), 1),
                  E(A(n(q), {
                    title: "Copy public path",
                    icon: "i-carbon-copy",
                    action: "",
                    mr1: "",
                    "mt--2px": "",
                    "flex-none": "",
                    border: !1,
                    onClick: c[1] || (c[1] = (B) => n(W)(n(s).publicPath, { type: "assets-public-path" }))
                  }, null, 512), [
                    [n(X), "Copy public path"]
                  ]),
                  A(R, {
                    to: n(s).publicPath,
                    target: "_blank"
                  }, {
                    default: C(() => [
                      E(A(n(q), {
                        icon: "i-carbon-launch",
                        action: "",
                        "flex-none": "",
                        border: !1,
                        title: "Open in Browser"
                      }, null, 512), [
                        [n(X), "Open in Browser"]
                      ])
                    ]),
                    _: 1
                  }, 8, ["to"])
                ])
              ])
            ]),
            l("tr", null, [
              c[5] || (c[5] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                op50: ""
              }, " Type ", -1)),
              l("td", oe, _(n(s).type), 1)
            ]),
            n(m)?.width ? (u(), h(z, { key: 0 }, [
              l("tr", null, [
                c[6] || (c[6] = l("td", {
                  "w-30": "",
                  "ws-nowrap": "",
                  pr5: "",
                  "text-right": "",
                  op50: ""
                }, " Image Size ", -1)),
                l("td", null, _(n(m).width) + " x " + _(n(m).height), 1)
              ]),
              n(v) ? (u(), h("tr", ie, [
                c[7] || (c[7] = l("td", {
                  "w-30": "",
                  "ws-nowrap": "",
                  pr5: "",
                  "text-right": "",
                  op50: ""
                }, " Aspect Ratio ", -1)),
                l("td", null, _(n(v)), 1)
              ])) : P("", !0)
            ], 64)) : P("", !0),
            l("tr", null, [
              c[8] || (c[8] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                op50: ""
              }, " File size ", -1)),
              l("td", null, _(n(f)), 1)
            ]),
            l("tr", null, [
              c[9] || (c[9] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                op50: ""
              }, " Last modified ", -1)),
              l("td", null, [
                H(_(new Date(n(s).mtime).toLocaleString()) + " ", 1),
                l("span", le, "(" + _(n(g)) + ")", 1)
              ])
            ]),
            l("tr", null, [
              c[10] || (c[10] = l("td", {
                "w-30": "",
                "ws-nowrap": "",
                pr5: "",
                "text-right": "",
                "align-top": "",
                op50: ""
              }, " Importers ", -1)),
              l("td", null, [
                n(d).length > 0 ? (u(!0), h(z, { key: 0 }, F(n(d), (B) => (u(), h("div", {
                  key: B.url,
                  flex: "~ gap-1",
                  "w-full": "",
                  "items-center": ""
                }, [
                  A(k, {
                    filepath: B.id || B.url,
                    "text-left": ""
                  }, null, 8, ["filepath"]),
                  n(o).vitePluginDetected.value && n(y) && B.id ? E((u(), S(n(q), {
                    key: 0,
                    title: "Open in Editor",
                    icon: "i-carbon-launch",
                    action: "",
                    "flex-none": "",
                    border: !1,
                    onClick: (N) => n(tt)(B.id)
                  }, null, 8, ["onClick"])), [
                    [n(X), "Open in Editor"]
                  ]) : P("", !0)
                ]))), 128)) : (u(), h(z, { key: 1 }, [
                  H(" None ")
                ], 64))
              ])
            ])
          ])
        ]),
        c[13] || (c[13] = l("div", {
          flex: "~ gap2",
          "mb--2": "",
          "items-center": "",
          op50: ""
        }, [
          l("div", { "x-divider": "" }),
          l("div", { "flex-none": "" }, " Actions "),
          l("div", { "x-divider": "" })
        ], -1)),
        l("div", ae, [
          A(n(Q), {
            to: n(s).publicPath,
            download: "",
            target: "_blank"
          }, {
            icon: C(() => [
              L(p.$slots, "i-carbon-download")
            ]),
            default: C(() => [
              c[11] || (c[11] = H(" Download ", -1))
            ]),
            _: 3
          }, 8, ["to"])
        ]),
        c[14] || (c[14] = l("div", { "flex-auto": "" }, null, -1)),
        n(U).length ? (u(), S(x, {
          key: 1,
          border: "t base",
          "mx--4": "",
          "mb--4": "",
          "code-snippets": n(U)
        }, null, 8, ["code-snippets"])) : P("", !0)
      ]);
    };
  }
}), ue = /* @__PURE__ */ T({
  __name: "AssetListItem",
  props: {
    item: {},
    index: { default: 0 },
    modelValue: {}
  },
  setup(a, { emit: i }) {
    const t = a, o = st(t, "modelValue", i, { passive: !0 }), s = w(() => t.item?.children?.length), r = D(!0), d = w(() => s.value ? "i-carbon-folder" : t.item.type === "image" ? "i-carbon-image" : t.item.type === "video" ? "i-carbon-video" : t.item.type === "audio" ? "i-carbon-volume-up" : t.item.type === "font" ? "i-carbon-text-small-caps" : t.item.type === "text" ? "i-carbon-document" : t.item.type === "json" ? "i-carbon-json" : t.item.type === "wasm" ? "i-vscode-icons-file-type-wasm" : "i-carbon-document-blank");
    return (y, m) => {
      const j = ot("AssetListItem", !0);
      return u(), h("div", null, [
        l("button", {
          flex: "~ gap-2",
          "w-full": "",
          "items-center": "",
          hover: "bg-active",
          px4: "",
          py1: "",
          style: nt({ paddingLeft: `calc(1rem + ${a.index * 1.5}em)` }),
          class: M({ "bg-active": !n(s) && n(o)?.filePath === a.item?.filePath }),
          border: "b base",
          onClick: m[0] || (m[0] = (V) => n(s) ? r.value = !n(r) : o.value = a.item)
        }, [
          l("div", {
            class: M(n(d))
          }, null, 2),
          l("span", {
            class: M({ "flex items-center": n(s) }),
            "flex-auto": "",
            "text-start": "",
            "text-sm": "",
            "font-mono": ""
          }, _(a.item.path), 3),
          n(s) ? (u(), S(n(q), {
            key: 0,
            icon: "carbon:chevron-right",
            "transform-rotate": n(r) ? 90 : 0,
            transition: ""
          }, null, 8, ["transform-rotate"])) : P("", !0)
        ], 6),
        n(r) ? L(y.$slots, "default", { key: 0 }, () => [
          (u(!0), h(z, null, F(a.item?.children, (V) => (u(), S(j, {
            key: V.filepath,
            modelValue: n(o),
            "onUpdate:modelValue": m[1] || (m[1] = (b) => G(o) ? o.value = b : null),
            item: V,
            index: a.index + 1
          }, null, 8, ["modelValue", "item", "index"]))), 128))
        ]) : P("", !0)
      ]);
    };
  }
}), ce = {
  flex: "~ col gap-1",
  hover: "bg-active",
  "items-center": "",
  "of-hidden": "",
  rounded: "",
  p2: ""
}, de = {
  "w-full": "",
  "of-hidden": "",
  truncate: "",
  "ws-nowrap": "",
  "text-center": "",
  "text-xs": ""
}, pe = /* @__PURE__ */ T({
  __name: "AssetGridItem",
  props: {
    asset: {},
    folder: {}
  },
  setup(a) {
    const i = a, t = w(() => i.folder && i.asset.path.startsWith(i.folder) ? i.asset.path.slice(i.folder.length) : i.asset.path);
    return (e, o) => {
      const s = it;
      return u(), h("button", ce, [
        A(s, {
          "h-30": "",
          "w-30": "",
          rounded: "",
          border: "~ base",
          asset: a.asset
        }, null, 8, ["asset"]),
        l("div", de, _(n(t)), 1)
      ]);
    };
  }
}), he = {
  flex: "~ col gap2",
  border: "b base",
  "navbar-glass": "",
  "flex-1": "",
  p4: ""
}, fe = {
  flex: "~ gap4",
  "items-center": ""
}, me = /* @__PURE__ */ T({
  __name: "Navbar",
  props: {
    search: {},
    noPadding: { type: Boolean }
  },
  emits: ["update:search"],
  setup(a, { emit: i }) {
    const t = a, e = i, o = D(t.search);
    return et(() => t.search, (s) => {
      o.value = s;
    }), et(o, () => {
      e("update:search", o.value);
    }), (s, r) => (u(), h("div", he, [
      l("div", fe, [
        L(s.$slots, "search", {}, () => [
          a.search !== void 0 ? (u(), S(n(ht), {
            key: 0,
            modelValue: n(o),
            "onUpdate:modelValue": r[0] || (r[0] = (d) => G(o) ? o.value = d : null),
            placeholder: "Search...",
            "left-icon": "i-carbon-search",
            class: M(["flex-auto", { "px-5 py-2": !a.noPadding }])
          }, null, 8, ["modelValue", "class"])) : P("", !0)
        ]),
        L(s.$slots, "actions")
      ]),
      L(s.$slots, "default")
    ]));
  }
}), ve = {
  block: "",
  "h-full": "",
  "of-hidden": "",
  class: "drawer-container relative"
}, ye = {
  "h-full": "",
  "w-full": "",
  "of-auto": ""
}, ge = {
  "flex-none": "",
  flex: "~ gap2 items-center",
  "text-lg": ""
}, xe = {
  flex: "~ items-center justify-center",
  absolute: "",
  "bottom-0": "",
  "right-2px": "",
  "h-4": "",
  "w-4": "",
  "rounded-full": "",
  "bg-primary-800": "",
  "text-8px": "",
  "text-white": ""
}, be = {
  "w-full": "",
  flex: "~ gap-2 items-center",
  rounded: "",
  px2: "",
  py2: ""
}, we = {
  "text-xs": "",
  op75: ""
}, $e = { op50: "" }, _e = { key: 0 }, ke = {
  "mt--4": "",
  px2: "",
  grid: "~ cols-minmax-8rem"
}, Be = {
  key: 1,
  p2: "",
  grid: "~ cols-minmax-8rem"
}, Ae = { key: 1 }, Ce = 50, Ve = /* @__PURE__ */ T({
  __name: "assets",
  setup(a) {
    const i = D(""), t = D(), e = D("grid"), o = D([]), s = w(() => {
      const g = [];
      for (const f of o.value || []) {
        const v = f.path.split(".").pop();
        v && !g.find((I) => I.value === v) && g.push({ label: v, value: v });
      }
      return g;
    }), r = D([]);
    ft(() => s.value, (g) => {
      r.value = g.map((f) => f.value);
    });
    const d = D(), y = w(() => new mt(o.value || [], {
      keys: [
        "path"
      ]
    })), m = w(() => (i.value ? y.value.search(i.value).map((f) => f.item) : o.value || []).filter((f) => {
      const v = f.path.split(".").pop();
      return !v || r.value.includes(v);
    })), j = w(() => {
      const g = {};
      for (const f of m.value) {
        const v = `${f.relativePath.split("/").slice(0, -1).join("/")}/`;
        g[v] || (g[v] = []), g[v].push(f);
      }
      return Object.entries(g).sort(([f], [v]) => f.localeCompare(v));
    }), V = w(() => {
      const g = { children: [] }, f = (v, I, p) => {
        const [c, ...$] = I;
        let k = v.children.find((R) => R.path === c);
        k || (k = { ...p, path: c, children: [] }, v.children.push(k)), $.length > 1 ? f(k, $, p) : $.length === 1 && k.children.push({ ...p, path: $[0] });
      };
      return m.value.forEach((v) => {
        const I = v.relativePath.split("/").filter((p) => p !== "");
        f(g, I, v);
      }), g.children;
    });
    function b() {
      K.value.getStaticAssets().then((g) => {
        o.value = g;
      });
    }
    function U() {
      b();
    }
    vt(() => {
      b(), K.functions.on("assetsUpdated", U);
    });
    function W() {
      e.value = e.value === "list" ? "grid" : "list";
    }
    return yt(() => {
      K.functions.off("assetsUpdated", U);
    }), (g, f) => {
      const v = _t, I = me, p = pe, c = $t, $ = ue, k = re, R = wt("tooltip");
      return u(), h("div", ve, [
        l("div", ye, [
          A(I, {
            ref_key: "navbar",
            ref: t,
            search: n(i),
            "onUpdate:search": f[1] || (f[1] = (x) => G(i) ? i.value = x : null),
            pb2: "",
            "no-padding": !0
          }, {
            actions: C(() => [
              l("div", ge, [
                A(n(xt), {
                  modelValue: n(r),
                  "onUpdate:modelValue": f[0] || (f[0] = (x) => G(r) ? r.value = x : null),
                  multiple: !0,
                  options: n(s)
                }, {
                  button: C(() => [
                    E((u(), S(v, {
                      icon: "i-carbon-filter hover:op50",
                      border: !1,
                      title: "Filter",
                      relative: "",
                      "cursor-pointer": "",
                      p2: "",
                      "text-lg": "",
                      onClick: () => {
                      }
                    }, {
                      default: C(() => [
                        l("span", xe, _(n(r).length), 1)
                      ]),
                      _: 1
                    })), [
                      [
                        R,
                        "Filter",
                        void 0,
                        { "bottom-end": !0 }
                      ]
                    ])
                  ]),
                  item: C(({
                    item: x,
                    active: B
                  }) => [
                    l("div", be, [
                      A(n(bt), { "model-value": B }, null, 8, ["model-value"]),
                      l("span", we, _(x.label), 1)
                    ])
                  ]),
                  _: 1
                }, 8, ["modelValue", "options"]),
                E(A(n(q), {
                  border: !1,
                  icon: n(e) === "grid" ? "i-carbon-list" : "i-carbon-grid",
                  title: "Toggle view",
                  action: "",
                  "cursor-pointer": "",
                  "text-lg": "",
                  onClick: W
                }, null, 8, ["icon"]), [
                  [
                    R,
                    "Toggle View",
                    void 0,
                    { "bottom-end": !0 }
                  ]
                ])
              ])
            ]),
            default: C(() => [
              l("div", $e, [
                n(i) ? (u(), h("span", _e, _(n(m).length) + " matched · ", 1)) : P("", !0),
                l("span", null, _(n(o)?.length) + " assets in total", 1)
              ])
            ]),
            _: 1
          }, 8, ["search"]),
          n(e) === "grid" ? (u(), h(z, { key: 0 }, [
            n(j).length > 1 ? (u(!0), h(z, { key: 0 }, F(n(j), ([x, B]) => (u(), S(c, {
              key: x,
              text: x,
              description: `${B.length} items`,
              open: B.length <= Ce,
              padding: !1
            }, {
              default: C(() => [
                l("div", ke, [
                  (u(!0), h(z, null, F(B, (N) => (u(), S(p, {
                    key: N.path,
                    asset: N,
                    folder: x,
                    onClick: (Pe) => d.value = N
                  }, null, 8, ["asset", "folder", "onClick"]))), 128))
                ])
              ]),
              _: 2
            }, 1032, ["text", "description", "open"]))), 128)) : (u(), h("div", Be, [
              (u(!0), h(z, null, F(n(m), (x) => (u(), S(p, {
                key: x.path,
                asset: x,
                onClick: (B) => d.value = x
              }, null, 8, ["asset", "onClick"]))), 128))
            ]))
          ], 64)) : (u(), h("div", Ae, [
            (u(!0), h(z, null, F(n(V), (x, B) => (u(), S($, {
              key: B,
              modelValue: n(d),
              "onUpdate:modelValue": f[2] || (f[2] = (N) => G(d) ? d.value = N : null),
              item: x
            }, null, 8, ["modelValue", "item"]))), 128))
          ]))
        ]),
        A(n(gt), {
          "model-value": !!n(d),
          top: n(t),
          permanent: "",
          "mount-to": ".drawer-container",
          position: "absolute",
          "content-class": "w120 text-sm",
          "onUpdate:modelValue": f[4] || (f[4] = (x) => {
            x || (d.value = void 0);
          })
        }, {
          default: C(() => [
            n(d) ? (u(), S(k, {
              key: 0,
              modelValue: n(d),
              "onUpdate:modelValue": f[3] || (f[3] = (x) => G(d) ? d.value = x : null)
            }, null, 8, ["modelValue"])) : P("", !0)
          ]),
          _: 1
        }, 8, ["model-value", "top"])
      ]);
    };
  }
});
export {
  Ve as default
};
