import { d as p, e as a, u as n, f as r, g as s, o as c, h as e } from "./index-BMNNx3yZ.js";
/* empty css               */
const d = /* @__PURE__ */ p({
  __name: "components",
  setup(m) {
    function o() {
      e.value.emit("toggle-panel", !1);
    }
    function t() {
      e.value.emit("toggle-panel", !0);
    }
    return (l, u) => (c(), a(n(s), {
      onOpenInEditor: n(r),
      onOnInspectComponentStart: o,
      onOnInspectComponentEnd: t
    }, null, 8, ["onOpenInEditor"]));
  }
});
export {
  d as default
};
