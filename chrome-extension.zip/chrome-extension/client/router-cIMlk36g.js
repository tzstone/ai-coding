import { d as n, y as c, i as o, e as u, u as t, k as p, o as i } from "./index-BMNNx3yZ.js";
/* empty css               */
const f = /* @__PURE__ */ n({
  __name: "router",
  setup(d) {
    const { registeredInspector: r } = c(), s = o(() => r.value?.find((e) => e.packageName === "vue-router")), a = o(() => s.value?.id);
    return (e, m) => (i(), u(t(p), { id: t(a) }, null, 8, ["id"]));
  }
});
export {
  f as default
};
