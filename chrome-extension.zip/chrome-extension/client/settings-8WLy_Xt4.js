import { d as ee, j as le, l as B, m as te, p as E, q as oe, i as ne, c as m, s as a, b as l, F as x, v as $, u as t, a as U, x as d, z as I, M as j, A as p, B as se, C as ae, o as r, e as F, t as O, D as R, n as z, _ as ie, E as D, G as ue, H as _, I as h, J as V, K as de } from "./index-BMNNx3yZ.js";
import { _ as re } from "./IconTitle.vue_vue_type_script_setup_true_lang-BCP3S8LV.js";
const pe = {
  "h-full": "",
  "w-full": "",
  "of-auto": "",
  px8: "",
  py6: ""
}, me = {
  grid: "~ md:cols-[repeat(auto-fit,minmax(16rem,1fr))] gap-x-10 gap-y-3",
  "max-w-300": ""
}, ve = { flex: "~ col gap-2" }, fe = {
  flex: "~ gap-2",
  "flex-auto": "",
  "items-center": "",
  "justify-start": ""
}, xe = {
  capitalize: "",
  op75: ""
}, ge = {
  flex: "~ gap-2",
  "flex-auto": "",
  "items-center": "",
  "justify-start": "",
  "pr-4": "",
  "text-sm": ""
}, ce = ["onClick"], be = ["onClick"], ye = ["onClick"], Ve = { flex: "~ col gap-2" }, ke = { flex: "~ gap2" }, Ce = { class: "flex items-center gap2 text-sm" }, we = { class: "flex items-center gap2 text-sm" }, Se = { class: "flex items-center gap2 text-sm" }, Te = { class: "flex items-center gap2 text-sm" }, Ue = { flex: "~ gap-2" }, De = /* @__PURE__ */ ee({
  __name: "settings",
  setup(Ie) {
    const { categorizedTabs: H } = le(), A = ae(), q = A === "iframe" || A === "separate-window", { scale: k, interactionCloseOnOutsideClick: C, showPanel: w, minimizePanelInteractive: g, expandSidebar: S, scrollableSidebar: T, reduceMotion: G } = B(te(E)), J = [
      ["Tiny", 12 / 15],
      ["Small", 14 / 15],
      ["Normal", 1],
      ["Large", 16 / 15],
      ["Huge", 18 / 15]
    ], K = [
      ["Always", 0],
      ["1s", 1e3],
      ["2s", 2e3],
      ["5s", 5e3],
      ["10s", 1e4],
      ["Never", -1]
    ], { hiddenTabCategories: c, hiddenTabs: b, pinnedTabs: i } = B(E.value.tabSettings);
    function Q(s, e) {
      e ? b.value = b.value.filter((u) => u !== s) : b.value.push(s);
    }
    function W(s, e) {
      e ? c.value = c.value.filter((u) => u !== s) : c.value.push(s);
    }
    function X(s) {
      i.value.includes(s) ? i.value = i.value.filter((e) => e !== s) : i.value.push(s);
    }
    function L(s, e) {
      const u = i.value.indexOf(s);
      if (u === -1)
        return;
      const v = u + e;
      if (v < 0 || v >= i.value.length)
        return;
      const o = [...i.value];
      o.splice(u, 1), o.splice(v, 0, s), i.value = o;
    }
    const y = oe(!1);
    async function Y() {
      de(), window.location.reload();
    }
    const M = K.map(([s, e]) => ({ label: s, value: e })), Z = ne(() => `${M.find((e) => e.value === g.value)?.label ?? "Select..."}`);
    return (s, e) => {
      const u = re, v = ie;
      return r(), m("div", pe, [
        a(u, {
          class: "mb-5 text-xl op75",
          icon: "i-carbon-settings-adjust",
          text: "DevTools Settings"
        }),
        l("div", me, [
          l("div", ve, [
            e[12] || (e[12] = l("h3", { "text-lg": "" }, " Tabs ", -1)),
            (r(!0), m(x, null, $(t(H), ([{ name: o, hidden: f }, N]) => (r(), m(x, { key: o }, [
              N.length ? (r(), F(t(I), {
                key: 0,
                p3: "",
                flex: "~ col gap-1",
                class: z(f ? "op50 grayscale" : "")
              }, {
                default: d(() => [
                  a(t(R), {
                    "model-value": !t(c).includes(o),
                    class: "row-reverse flex py1 pl2 pr1 hover:bg-active",
                    "onUpdate:modelValue": (n) => W(o, n)
                  }, {
                    default: d(() => [
                      l("div", fe, [
                        l("span", xe, O(o), 1)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["model-value", "onUpdate:modelValue"]),
                  e[11] || (e[11] = l("div", {
                    "mx--1": "",
                    my1: "",
                    "h-1px": "",
                    border: "b base",
                    op75: ""
                  }, null, -1)),
                  (r(!0), m(x, null, $(N, (n) => (r(), F(t(R), {
                    key: n.name,
                    class: z(["row-reverse n-primary flex py1 pl2 pr1 hover:bg-active", n.hidden ? "op35" : ""]),
                    "model-value": !t(b).includes(n.name),
                    "onUpdate:modelValue": (P) => Q(n.name, P)
                  }, {
                    default: d(() => [
                      l("div", ge, [
                        a(v, {
                          "text-xl": "",
                          icon: n.icon,
                          fallback: n.fallbackIcon,
                          title: n.title
                        }, null, 8, ["icon", "fallback", "title"]),
                        l("span", null, O(n.title), 1),
                        e[10] || (e[10] = l("div", { "flex-auto": "" }, null, -1)),
                        t(i).includes(n.name) ? (r(), m(x, { key: 0 }, [
                          l("button", {
                            class: "flex items-center px1 py1 text-sm op65 hover:bg-active hover:op100",
                            onClick: D(() => {
                              t(i).indexOf(n.name) !== 0 && L(n.name, -1);
                            }, ["stop"])
                          }, [...e[8] || (e[8] = [
                            l("div", { class: "i-carbon-caret-up" }, null, -1)
                          ])], 8, ce),
                          l("button", {
                            class: "flex items-center px1 py1 text-sm op65 hover:bg-active hover:op100",
                            onClick: D(() => {
                              t(i).indexOf(n.name) !== t(i).length - 1 && L(n.name, 1);
                            }, ["stop"])
                          }, [...e[9] || (e[9] = [
                            l("div", { class: "i-carbon-caret-down" }, null, -1)
                          ])], 8, be)
                        ], 64)) : U("", !0),
                        l("button", {
                          class: "flex items-center px1 py1 text-sm op65 hover:bg-active hover:op100",
                          onClick: D((P) => X(n.name), ["stop"])
                        }, [
                          l("div", {
                            class: z(t(i).includes(n.name) ? " i-carbon-pin-filled rotate--45" : " i-carbon-pin op45")
                          }, null, 2)
                        ], 8, ye)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["model-value", "class", "onUpdate:modelValue"]))), 128))
                ]),
                _: 2
              }, 1032, ["class"])) : U("", !0)
            ], 64))), 128))
          ]),
          l("div", Ve, [
            e[25] || (e[25] = l("h3", { "text-lg": "" }, " Appearance ", -1)),
            a(t(I), {
              p4: "",
              flex: "~ col gap-2"
            }, {
              default: d(() => [
                l("div", ke, [
                  a(t(ue), {
                    animation: !t(G)
                  }, {
                    default: d(({ isDark: o, toggle: f }) => [
                      a(t(j), {
                        outlined: "",
                        type: "primary",
                        onClick: f
                      }, {
                        default: d(() => [
                          e[13] || (e[13] = l("div", {
                            "i-carbon-sun": "",
                            "dark:i-carbon-moon": "",
                            "translate-y--1px": ""
                          }, null, -1)),
                          _(" " + O(o ? "Dark" : "Light"), 1)
                        ]),
                        _: 2
                      }, 1032, ["onClick"])
                    ]),
                    _: 1
                  }, 8, ["animation"])
                ]),
                e[16] || (e[16] = l("div", {
                  "mx--2": "",
                  my1: "",
                  "h-1px": "",
                  border: "b base",
                  op75: ""
                }, null, -1)),
                e[17] || (e[17] = l("p", null, "UI Scale", -1)),
                l("div", null, [
                  a(t(h), {
                    modelValue: t(k),
                    "onUpdate:modelValue": e[0] || (e[0] = (o) => p(k) ? k.value = o : null),
                    options: J.map(([o, f]) => ({ label: o, value: f })),
                    "button-props": { outlined: !0 }
                  }, null, 8, ["modelValue", "options"])
                ]),
                e[18] || (e[18] = l("div", {
                  "mx--2": "",
                  my1: "",
                  "h-1px": "",
                  border: "b base",
                  op75: ""
                }, null, -1)),
                l("div", Ce, [
                  a(t(V), {
                    modelValue: t(S),
                    "onUpdate:modelValue": e[1] || (e[1] = (o) => p(S) ? S.value = o : null)
                  }, null, 8, ["modelValue"]),
                  e[14] || (e[14] = l("span", { op75: "" }, "Expand Sidebar", -1))
                ]),
                l("div", we, [
                  a(t(V), {
                    modelValue: t(T),
                    "onUpdate:modelValue": e[2] || (e[2] = (o) => p(T) ? T.value = o : null)
                  }, null, 8, ["modelValue"]),
                  e[15] || (e[15] = l("span", { op75: "" }, "Scrollable Sidebar", -1))
                ])
              ]),
              _: 1
            }),
            t(q) ? (r(), m(x, { key: 0 }, [
              e[23] || (e[23] = l("h3", {
                mt2: "",
                "text-lg": ""
              }, " Features ", -1)),
              a(t(I), {
                p4: "",
                flex: "~ col gap-2"
              }, {
                default: d(() => [
                  l("div", Se, [
                    a(t(V), {
                      modelValue: t(C),
                      "onUpdate:modelValue": e[3] || (e[3] = (o) => p(C) ? C.value = o : null)
                    }, null, 8, ["modelValue"]),
                    e[19] || (e[19] = l("span", { op75: "" }, "Close DevTools when clicking outside", -1))
                  ]),
                  l("div", Te, [
                    a(t(V), {
                      modelValue: t(w),
                      "onUpdate:modelValue": e[4] || (e[4] = (o) => p(w) ? w.value = o : null)
                    }, null, 8, ["modelValue"]),
                    e[20] || (e[20] = l("span", { op75: "" }, "Always show the floating panel", -1))
                  ]),
                  e[21] || (e[21] = l("div", {
                    "mx--2": "",
                    my1: "",
                    "h-1px": "",
                    border: "b base",
                    op75: ""
                  }, null, -1)),
                  e[22] || (e[22] = l("p", null, "Minimize floating panel on inactive", -1)),
                  l("div", null, [
                    a(t(h), {
                      modelValue: t(g),
                      "onUpdate:modelValue": e[5] || (e[5] = (o) => p(g) ? g.value = o : null),
                      "button-props": { outlined: !0 },
                      options: t(M),
                      placeholder: t(Z)
                    }, null, 8, ["modelValue", "options", "placeholder"])
                  ])
                ]),
                _: 1
              })
            ], 64)) : U("", !0),
            e[26] || (e[26] = l("h3", {
              mt2: "",
              "text-lg": ""
            }, " Debug ", -1)),
            l("div", Ue, [
              a(t(j), {
                outlined: "",
                type: "warning",
                onClick: e[6] || (e[6] = (o) => y.value = !0)
              }, {
                default: d(() => [...e[24] || (e[24] = [
                  l("div", { "i-carbon-breaking-change": "" }, null, -1),
                  _(" Reset Local Settings & State ", -1)
                ])]),
                _: 1
              }),
              a(t(se), {
                modelValue: t(y),
                "onUpdate:modelValue": e[7] || (e[7] = (o) => p(y) ? y.value = o : null),
                title: "Clear Local Settings & State",
                width: "40%",
                height: "200px",
                content: "Are you sure you to reset all local settings & state? Devtools will reload.",
                onConfirm: Y
              }, null, 8, ["modelValue"])
            ])
          ])
        ])
      ]);
    };
  }
});
export {
  De as default
};
