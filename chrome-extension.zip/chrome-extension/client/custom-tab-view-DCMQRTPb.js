import { d as r, j as m, i as a, L as l, N as i, O as p, e as _, u as f, P as b, o as d } from "./index-BMNNx3yZ.js";
const k = /* @__PURE__ */ r({
  __name: "custom-tab-view",
  setup(v) {
    const o = l(), s = p(), { flattenedTabs: n } = m(), u = a(() => o.params.name), t = a(() => n.value.find((e) => u.value === e.name) || null);
    return i(() => {
      if (!t.value) {
        const e = setTimeout(() => {
          if (t.value) {
            clearTimeout(e);
            return;
          }
          s.replace("/overview");
        }, 2e3);
      }
    }), (e, T) => {
      const c = b;
      return d(), _(c, { tab: f(t) }, null, 8, ["tab"]);
    };
  }
});
export {
  k as default
};
