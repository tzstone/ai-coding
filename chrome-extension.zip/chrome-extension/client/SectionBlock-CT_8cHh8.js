import { _ as x } from "./IconTitle.vue_vue_type_script_setup_true_lang-BCP3S8LV.js";
import { d as g, c, o as i, F as y, b as o, u as l, S as B, T as $, n as r, s as h, x as b, r as s, e as k, a as d, U as C, V, H as u, t as p, W as w } from "./index-BMNNx3yZ.js";
const S = ["open"], N = { "text-base": "" }, T = {
  key: 0,
  "text-sm": "",
  op50: ""
}, z = /* @__PURE__ */ g({
  __name: "SectionBlock",
  props: {
    icon: {},
    text: {},
    description: {},
    containerClass: { default: "" },
    collapse: { type: Boolean, default: !0 },
    open: { type: Boolean, default: !0 },
    padding: { type: [Boolean, String], default: !0 }
  },
  setup(e) {
    const n = B(e, "open", void 0, { passive: !0 });
    function v(t) {
      n.value = t.target.open;
    }
    return (t, a) => {
      const f = x, m = V("lazy-show");
      return i(), c(y, null, [
        o("details", {
          open: l(n),
          onToggle: v
        }, [
          o("summary", {
            class: r(["cursor-pointer select-none p4 hover:bg-active", e.collapse ? "" : "pointer-events-none"])
          }, [
            h(f, {
              icon: e.icon,
              text: e.text,
              "text-xl": "",
              transition: "",
              class: r(l(n) ? "op100" : "op60")
            }, {
              default: b(() => [
                o("div", null, [
                  o("div", N, [
                    s(t.$slots, "text", {}, () => [
                      u(p(e.text), 1)
                    ], !0)
                  ]),
                  e.description || t.$slots.description ? (i(), c("div", T, [
                    s(t.$slots, "description", {}, () => [
                      u(p(e.description), 1)
                    ], !0)
                  ])) : d("", !0)
                ]),
                a[0] || (a[0] = o("div", { class: "flex-auto" }, null, -1)),
                s(t.$slots, "actions", {}, void 0, !0),
                e.collapse ? (i(), k(l(C), {
                  key: 0,
                  icon: "i-carbon-chevron-down",
                  class: "chevron",
                  "cursor-pointer": "",
                  "place-self-start": "",
                  "text-base": "",
                  op75: "",
                  transition: "",
                  "duration-500": ""
                })) : d("", !0)
              ]),
              _: 3
            }, 8, ["icon", "text", "class"])
          ], 2),
          $((i(), c("div", {
            class: r(["flex flex-col flex-gap2 pb6 pt2", typeof e.padding == "string" ? e.padding : e.padding ? "px4" : ""])
          }, [
            s(t.$slots, "details", {}, void 0, !0),
            o("div", {
              class: r([e.containerClass, "mt1"])
            }, [
              s(t.$slots, "default", {}, void 0, !0)
            ], 2),
            s(t.$slots, "footer", {}, void 0, !0)
          ], 2)), [
            [m, l(n)]
          ])
        ], 40, S),
        a[1] || (a[1] = o("div", { class: "x-divider" }, null, -1))
      ], 64);
    };
  }
}), E = /* @__PURE__ */ w(z, [["__scopeId", "data-v-d1d325e5"]]);
export {
  E as _
};
