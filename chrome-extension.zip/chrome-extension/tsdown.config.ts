import { defineConfig } from 'tsdown'

const NO_EXTERNAL = ['@vue/devtools-core', '@vue/devtools-kit', '@vue/devtools-shared']

function createIIFEConfig(entry: string) {
  return {
    entry: [entry],
    clean: false,
    format: 'iife' as const,
    fixedExtension: false,
    outputOptions: {
      entryFileNames: '[name].js',
    },
    define: {
      'process.env': JSON.stringify({
        NODE_ENV: 'production',
      }),
      '__VUE_OPTIONS_API__': 'true',
      '__VUE_PROD_DEVTOOLS__': 'true',
    },
    deps: {
      alwaysBundle: NO_EXTERNAL,
    },
  }
}

export default defineConfig([
  createIIFEConfig('src/background.ts'),
  createIIFEConfig('src/detector.ts'),
  createIIFEConfig('src/devtools-background.ts'),
  createIIFEConfig('src/devtools-panel.ts'),
  createIIFEConfig('src/user-app.ts'),
  createIIFEConfig('src/proxy.ts'),
  createIIFEConfig('src/prepare.ts'),
  createIIFEConfig('src/devtools-overlay.ts'),
])
